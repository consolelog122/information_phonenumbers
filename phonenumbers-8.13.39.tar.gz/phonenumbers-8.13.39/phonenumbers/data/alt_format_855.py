"""Auto-generated file, do not edit by hand. 855 metadata"""
from ..phonemetadata import NumberFormat

PHONE_ALT_FORMAT_855 = [NumberFormat(pattern='(\\d{2})(\\d{2})(\\d{2})(\\d{2,3})', format='\\1 \\2 \\3 \\4')]
